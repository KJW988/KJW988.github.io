'use strict';
(() => {
  const decks = window.SEMINAR_DECKS;
  if (!Array.isArray(decks) || !decks.length) return;
  const $ = id => document.getElementById(id);
  const player = $('player');
  const lang = 'ko';
  let di = 0, si = 0, bi = 0;
  let imageRevision = 0, swipeStart = null;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const text = {
    ko: {skip:'슬라이드로 이동',preview:'미리보기',heading:'세미나 자료',description:'PPT의 설명 순서는 한 단계씩, 움직이는 자료는 원래 자리에서.',sample:'우선 공개한 3개 발표자료의<br>일부 슬라이드입니다.',zoom:'확대',fullscreen:'전체 화면',exitFullscreen:'전체 화면 종료',thumbnails:'슬라이드 목록',keyboard:'<kbd>←</kbd> <kbd>→</kbd> 이전·다음 단계 &nbsp; <kbd>Shift</kbd> + <kbd>→</kbd> 다음 장 &nbsp; <kbd>F</kbd> 전체 화면',swipe:'모바일에서는 좌우로 넘겨보세요.',info:'자료 선택과 슬라이드 이동만 남겼습니다. 단계가 있는 장은 같은 ‘다음’ 조작으로 내용을 이어서 보여줍니다.',scopeHeading:'샘플 범위와 변환 참고',home:'홈으로 ↗',zoomHint:'확대 화면 · 스크롤하여 이동',close:'닫기 ×',loadError:'슬라이드를 불러오지 못했습니다. 파일 경로를 확인해 주세요.',play:'움직임 재생',pause:'움직임 정지',original:'원본',stage:'단계',sampleLabel:'샘플',prev:'이전 단계',next:'다음 단계',choose:'발표자료 선택'},
  };
  const scopeKorean = $('scope-copy').innerHTML;
  function deck() { return decks[di]; }
  function slide() { return deck().slides[si]; }
  function el(tag, className, content) { const n=document.createElement(tag); if(className)n.className=className;if(content!==undefined)n.textContent=content;return n; }
  function applyBox(node, m) { Object.assign(node.style,{left:(m.x*100)+'%',top:(m.y*100)+'%',width:(m.w*100)+'%',height:(m.h*100)+'%'}); }
  function pauseMedia() { $('media-layer').querySelectorAll('video').forEach(v=>v.pause()); }
  function updateMediaControl() { const videos=[...$('media-layer').querySelectorAll('video')]; $('motion').hidden=!videos.length; $('motion').textContent=videos.some(v=>!v.paused)?text[lang].pause:text[lang].play; }
  function mountMedia() {
    pauseMedia(); $('media-layer').replaceChildren();
    for(const m of slide().media) {
      const v=el('video','media-item');v.src=m.src;v.poster=m.poster;v.preload='metadata';v.setAttribute('controlsList','nodownload');v.disablePictureInPicture=true;v.muted=true;v.loop=true;v.playsInline=true;v.setAttribute('aria-label',lang==='ko'?'원본 GIF에서 추출한 움직이는 자료':'Animated media extracted from the original GIF');applyBox(v,m);
      v.addEventListener('play',updateMediaControl);v.addEventListener('pause',updateMediaControl);
      $('media-layer').append(v);
      if(!reduced)v.play().catch(updateMediaControl);
    }
    updateMediaControl();
  }
  function renderDecks() {
    const parent=document.querySelector('.deck-list'); parent.replaceChildren();parent.setAttribute('aria-label',text[lang].choose);
    decks.forEach((d,i)=>{const button=el('button','deck-choice');button.type='button';button.dataset.deck=d.id;button.setAttribute('aria-pressed',String(i===di));const image=el('img');image.src=d.slides[0].thumbnail;image.alt='';image.width=160;image.height=90;const copy=el('span');copy.append(el('strong','',d.title),el('small','',d.description));button.append(image,copy);button.addEventListener('click',()=>{di=i;si=bi=0;updateHash();render();});parent.append(button);});
  }
  function renderThumbs() {
    $('thumbnails').replaceChildren();deck().slides.forEach((s,i)=>{const b=el('button','thumb');b.type='button';b.setAttribute('aria-current',String(i===si));b.setAttribute('aria-label',`${text[lang].original} ${s.original}: ${s.label}`);const img=el('img');img.src=s.thumbnail;img.alt='';img.loading='lazy';b.append(img,el('span','',`${text[lang].original} ${s.original} · ${s.frames.length>1?(lang==='ko'?'단계 '+s.frames.length:s.frames.length+' builds'):(lang==='ko'?'1장':'1 slide')}`));b.addEventListener('click',()=>{si=i;bi=0;updateHash();render();});$('thumbnails').append(b);});
  }
  function updateHash() { const h=`#${deck().id}/${slide().original}/${bi}`; if(location.hash!==h){try{history.replaceState(null,'',h);}catch(_){/* Sandboxed preview: navigation still works. */}} }
  function readHash() {
    const m=location.hash.match(/^#([a-z0-9-]+)\/(\d+)\/(\d+)$/);
    if(!m)return;
    const i=decks.findIndex(d=>d.id===m[1]);if(i<0)return;di=i;
    const j=deck().slides.findIndex(s=>s.original===Number(m[2]));si=Math.max(0,j);bi=Math.min(slide().frames.length-1,Math.max(0,Number(m[3])));
  }
  // Equal X/Y scale in normal, full-screen and enlarged views.
  function pageRatio() {
    const d=slide().dimensions;
    if(d && d.width>0 && d.height>0)return d.width/d.height;
    const im=$('slide-image');
    return im.naturalWidth>0 && im.naturalHeight>0 ? im.naturalWidth/im.naturalHeight : 16/9;
  }
  function fitStage() {
    const ratio=pageRatio(), outer=document.querySelector('.stage-outer');
    const stageNode=document.querySelector('.stage');
    const presenting=Boolean(document.fullscreenElement)||player.classList.contains('presentation-mode');
    const availableHeight=presenting
      ? Math.max(80,player.clientHeight-document.querySelector('.player-top').getBoundingClientRect().height-document.querySelector('.player-controls').getBoundingClientRect().height-$('progress').getBoundingClientRect().height)
      : Math.max(160,window.innerHeight*.75);
    const w=Math.min(outer.clientWidth,availableHeight*ratio);
    if(!(w>0))return;
    stageNode.style.setProperty('--slide-ratio',String(ratio));
    stageNode.style.width=w+'px';stageNode.style.height=(w/ratio)+'px';
  }
  function render() {
    const d=deck(),s=slide(); const revision=++imageRevision;
    renderDecks();$('deck-title').textContent=d.title;$('slide-label').textContent=s.label;
    $('slide-image').alt=`${d.title} · ${text[lang].original} ${s.original} · ${text[lang].stage} ${bi+1}/${s.frames.length}`;
    $('load-error').hidden=true;$('slide-image').onerror=()=>{if(revision===imageRevision)$('load-error').hidden=false;};$('slide-image').onload=fitStage;$('slide-image').src=s.frames[bi];fitStage();requestAnimationFrame(fitStage);
    $('original-count').textContent=`${text[lang].original} ${s.original} / ${d.originalCount}`;
    $('build-count').textContent=s.frames.length>1?`${text[lang].stage} ${bi+1} / ${s.frames.length}`:'';
    $('sample-count').textContent=`${text[lang].sampleLabel} ${si+1} / ${d.slides.length}`;
    $('prev').disabled=si===0&&bi===0;$('next').disabled=si===d.slides.length-1&&bi===s.frames.length-1;
    $('prev').setAttribute('aria-label',text[lang].prev);$('next').setAttribute('aria-label',text[lang].next);
    const before=d.slides.slice(0,si).reduce((a,v)=>a+v.frames.length,0),all=d.slides.reduce((a,v)=>a+v.frames.length,0);
    $('progress').firstElementChild.style.width=((before+bi+1)/all*100)+'%';
    renderThumbs();mountMedia();
    const upcoming=bi+1<s.frames.length?s.frames[bi+1]:d.slides[si+1]?.frames[0];if(upcoming){const im=new Image();im.src=upcoming;}
  }
  function move(direction, whole=false) {
    if(whole){const n=Math.max(0,Math.min(deck().slides.length-1,si+direction));if(n===si)return;si=n;bi=0;}
    else if(direction>0){if(bi+1<slide().frames.length)bi++;else if(si+1<deck().slides.length){si++;bi=0;}else return;}
    else {if(bi>0)bi--;else if(si>0){si--;bi=slide().frames.length-1;}else return;}
    updateHash();render();
  }
  function localize() {
    document.documentElement.lang=lang;document.title=(lang==='ko'?'세미나 슬라이드쇼':'Seminar slideshow')+' · Jiwon Kim';
    document.querySelectorAll('[data-i18n]').forEach(e=>{const v=text[lang][e.dataset.i18n];if(v)e.innerHTML=v;});
    document.querySelectorAll('[data-lang]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lang===lang)));
    $('scope-copy').innerHTML=scopeKorean;render();
  }
  $('prev').addEventListener('click',()=>move(-1));$('next').addEventListener('click',()=>move(1));
  $('motion').addEventListener('click',()=>{const v=[...$('media-layer').querySelectorAll('video')];if(v.some(x=>!x.paused))v.forEach(x=>x.pause());else v.forEach(x=>x.play().catch(()=>{}));updateMediaControl();});
  $('thumbnails-toggle').addEventListener('click',()=>{const open=$('thumbnails').hidden;$('thumbnails').hidden=!open;$('thumbnails-toggle').setAttribute('aria-expanded',String(open));});
  async function fullscreen() {
    try {if(document.fullscreenElement)await document.exitFullscreen();else if(player.classList.contains('presentation-mode'))player.classList.remove('presentation-mode');else if(player.requestFullscreen)await player.requestFullscreen();else player.classList.add('presentation-mode');}
    catch(_){player.classList.toggle('presentation-mode');}
    $('fullscreen').textContent=(document.fullscreenElement||player.classList.contains('presentation-mode'))?text[lang].exitFullscreen:text[lang].fullscreen;requestAnimationFrame(fitStage);
  }
  $('fullscreen').addEventListener('click',fullscreen);document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?text[lang].exitFullscreen:text[lang].fullscreen;requestAnimationFrame(fitStage);});
  function zoom() {
    pauseMedia();$('zoom-image').src=$('slide-image').src;$('zoom-image').alt=$('slide-image').alt;$('zoom-media').replaceChildren();
    slide().media.forEach((m,i)=>{const image=el('img','media-item');image.src=m.poster;image.alt='';applyBox(image,m);const video=$('media-layer').querySelectorAll('video')[i];try{if(video.readyState>=2){const c=document.createElement('canvas');c.width=video.videoWidth;c.height=video.videoHeight;c.getContext('2d').drawImage(video,0,0);image.src=c.toDataURL('image/png');}}catch(_){}$('zoom-media').append(image);});
    const zoomCanvas=document.querySelector('.zoom-canvas');zoomCanvas.style.setProperty('--slide-ratio',String(pageRatio()));if(document.fullscreenElement)player.append($('zoom-dialog'));$('zoom-dialog').showModal();
  }
  $('zoom').addEventListener('click',zoom);$('zoom-close').addEventListener('click',()=>{$('zoom-dialog').close();document.body.append($('zoom-dialog'));});
  $('zoom-dialog').addEventListener('close',()=>document.body.append($('zoom-dialog')));
  document.addEventListener('keydown',e=>{
    if($('zoom-dialog').open)return;
    if(e.key==='Escape'){player.classList.remove('presentation-mode');requestAnimationFrame(fitStage);return;}
    if(e.ctrlKey||e.metaKey||e.altKey||/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName))return;
    if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();move(1,e.shiftKey);}
    else if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();move(-1,e.shiftKey);}
    else if(e.key.toLowerCase()==='f'){e.preventDefault();fullscreen();}
  });
  const stage=document.querySelector('.stage');
  stage.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')swipeStart={x:e.clientX,y:e.clientY};});
  stage.addEventListener('pointerup',e=>{if(!swipeStart)return;const dx=e.clientX-swipeStart.x,dy=e.clientY-swipeStart.y;swipeStart=null;if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.7)move(dx<0?1:-1);});
  stage.addEventListener('pointercancel',()=>swipeStart=null);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseMedia();});
  window.addEventListener('hashchange',()=>{readHash();render();});
  window.addEventListener('resize',fitStage);
  if('ResizeObserver' in window)new ResizeObserver(fitStage).observe(document.querySelector('.stage-outer'));
  readHash();localize();
})();
